import math
import random
import time
import asyncio
import pygame

# Initialize Pygame
pygame.init()

# Window Configuration
WIDTH, HEIGHT = 800, 800
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Fruit Aim Trainer")

# Constants
TARGET_INCREMENT = 1000
TARGET_EVENT = pygame.USEREVENT
TARGET_PADDING = 40
TOP_BAR_HEIGHT = 110 
GAME_DURATION = 60 

# Colors
BG_COLOR = (10, 20, 30)
COLOR_WHITE = (255, 255, 255)
COLOR_BLACK = (0, 0, 0)
LABEL_FONT = pygame.font.SysFont("comicsans", 22)
TITLE_FONT = pygame.font.SysFont("comicsans", 40)

class Target:
    MAX_SIZE = 35
    GROWTH_RATE = 0.2

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.size = 0
        self.grow = True
        self.fruit_type = random.randint(0, 5) # 0 to 5 for 6 fruits
        
        if self.fruit_type == 0: self.points = 10    # Orange
        elif self.fruit_type == 1: self.points = 20  # Grape
        elif self.fruit_type == 2: self.points = 30  # Watermelon
        elif self.fruit_type == 3: self.points = 40  # Banana
        elif self.fruit_type == 4: self.points = 50  # Mango
        else: self.points = 100                     # Apple

    def update(self):
        if self.size + self.GROWTH_RATE >= self.MAX_SIZE:
            self.grow = False
        if self.grow:
            self.size += self.GROWTH_RATE
        else:
            self.size -= self.GROWTH_RATE

    def draw(self, win):
        if self.size <= 0: return
        
        if self.fruit_type == 0: # Orange
            pygame.draw.circle(win, (255, 140, 0), (int(self.x), int(self.y)), int(self.size))
            pygame.draw.circle(win, (34, 139, 34), (int(self.x + 2), int(self.y - self.size - 2)), max(1, int(self.size // 3)))
            
        elif self.fruit_type == 1: # Grape
            pygame.draw.circle(win, (128, 0, 128), (int(self.x), int(self.y)), int(self.size))
            pygame.draw.circle(win, (180, 80, 255), (int(self.x - self.size // 4), int(self.y - self.size // 4)), max(1, int(self.size // 3)))
            
        elif self.fruit_type == 2: # Watermelon
            pygame.draw.circle(win, (34, 139, 34), (int(self.x), int(self.y)), int(self.size))
            pygame.draw.circle(win, (200, 30, 30), (int(self.x), int(self.y)), int(self.size * 0.8))
            pygame.draw.line(win, (10, 80, 10), (int(self.x - self.size), int(self.y)), (int(self.x + self.size), int(self.y)), 2)
            
        elif self.fruit_type == 3: # Banana
            pygame.draw.ellipse(win, (255, 225, 50), (int(self.x - self.size), int(self.y - self.size // 2), int(self.size * 2), int(self.size)))
            pygame.draw.circle(win, (100, 60, 20), (int(self.x - self.size), int(self.y)), max(1, int(self.size // 5)))
            
        elif self.fruit_type == 4: # Mango
            pygame.draw.ellipse(win, (255, 170, 0), (int(self.x - self.size * 0.8), int(self.y - self.size), int(self.size * 1.6), int(self.size * 2)))
            pygame.draw.circle(win, (34, 139, 34), (int(self.x), int(self.y - self.size)), max(1, int(self.size // 4)))
            
        elif self.fruit_type == 5: # Apple
            pygame.draw.circle(win, (220, 20, 60), (int(self.x), int(self.y)), int(self.size))
            pygame.draw.rect(win, (100, 60, 20), (int(self.x - 2), int(self.y - self.size - 4), 4, 8))
    def collide(self, x, y):
        dis = math.sqrt((x - self.x)**2 + (y - self.y)**2)
        return dis <= self.size

def format_time(secs):
    milli = math.floor(int(secs * 1000 % 1000) / 100)
    seconds = int(secs % 60)
    return f"{seconds:02d}.{milli}"

def draw_top_bar(win, remaining_time, score, counts, misses):
    pygame.draw.rect(win, (180, 180, 180), (0, 0, WIDTH, TOP_BAR_HEIGHT))
    time_label = LABEL_FONT.render(f"TIME: {format_time(remaining_time)}", 1, COLOR_BLACK)
    score_label = TITLE_FONT.render(f"SCORE: {score}", 1, (0, 50, 150))
    win.blit(time_label, (20, 10))
    win.blit(score_label, (WIDTH//2 - score_label.get_width()//2, 5))
    
    line1 = [
        (f"Orange: {counts['orange']}", (200, 100, 0), 20),
        (f"Grape: {counts['grape']}", (100, 0, 100), 160),
        (f"Melon: {counts['melon']}", (0, 120, 0), 290),
        (f"Banana: {counts['banana']}", (180, 160, 0), 430),
        (f"Mango: {counts['mango']}", (200, 120, 0), 570)
    ]
    for text, color, x_pos in line1:
        lbl = LABEL_FONT.render(text, 1, color)
        win.blit(lbl, (x_pos, 70))
    
    miss_lbl = LABEL_FONT.render(f"Missed: {misses}", 1, (50, 50, 50))
    win.blit(miss_lbl, (650, 10))

def end_screen(win, score, counts, hits, clicks):
    win.fill(BG_COLOR)
    accuracy = round(hits / max(1, clicks) * 100, 1)
    
    texts = [
        ("GAME OVER", (255, 0, 0), 80, TITLE_FONT),
        (f"Final Score: {score}", COLOR_WHITE, 160, LABEL_FONT),
        (f"Oranges: {counts['orange']} | Grapes: {counts['grape']} | Melons: {counts['melon']}", (200, 200, 200), 220, LABEL_FONT),
        (f"Bananas: {counts['banana']} | Mangos: {counts['mango']} | Apples: {counts['apple']}", (200, 200, 200), 260, LABEL_FONT),
        (f"Accuracy: {accuracy}%", COLOR_WHITE, 320, LABEL_FONT),
        ("Press 'R' to Restart or 'Q' to Quit", (255, 255, 0), 420, LABEL_FONT)
    ]

    for text, color, y, font in texts:
        label = font.render(text, 1, color)
        win.blit(label, (WIDTH/2 - label.get_width()/2, y))

    pygame.display.update()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return True # Signal to restart
                if event.key == pygame.K_q:
                    return False # Signal to quit

def draw_start_screen(win):
    win.fill(BG_COLOR)
    title = TITLE_FONT.render("FRUIT AIM TRAINER", 1, COLOR_WHITE)
    msg1 = LABEL_FONT.render("Press 'S' to Start", 1, (0, 255, 0))
    msg2 = LABEL_FONT.render("Press 'Q' to Quit", 1, (255, 50, 50))
    win.blit(title, (WIDTH//2 - title.get_width()//2, 250))
    win.blit(msg1, (WIDTH//2 - msg1.get_width()//2, 350))
    win.blit(msg2, (WIDTH//2 - msg2.get_width()//2, 400))
    pygame.display.update()

def start_screen(win):
    waiting = True
    while waiting:
        draw_start_screen(win)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    return True
                if event.key == pygame.K_q:
                    return False

def main():
    if not start_screen(WIN):
        pygame.quit()
        return

    while True: # Outer loop for restarts
        run = True
        targets = []
        clock = pygame.time.Clock()
        score, hits, clicks, misses = 0, 0, 0, 0
        counts = {"orange": 0, "grape": 0, "melon": 0, "banana": 0, "mango": 0, "apple": 0}
        
        MAX_TARGETS = 5
        start_time = time.time()
        pygame.time.set_timer(TARGET_EVENT, TARGET_INCREMENT)

        restart = False
        while run:
            clock.tick(60)
            await asyncio.sleep(0)  # Yields execution to the web browser main thread
            click_occurred = False
            mouse_pos = pygame.mouse.get_pos()
            
            remaining_time = max(0, GAME_DURATION - (time.time() - start_time))
            if remaining_time <= 0:
                restart = end_screen(WIN, score, counts, hits, clicks)
                run = False
                break

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        pygame.quit(); exit()
                    if event.key == pygame.K_r:
                        restart = True
                        run = False
                        break
                if event.type == TARGET_EVENT:
                    if len(targets) < MAX_TARGETS:
                        x = random.randint(TARGET_PADDING, WIDTH - TARGET_PADDING)
                        y = random.randint(TARGET_PADDING + TOP_BAR_HEIGHT, HEIGHT - TARGET_PADDING)
                        targets.append(Target(x, y))
                if event.type == pygame.MOUSEBUTTONDOWN:
                    click_occurred = True
                    clicks += 1
                    
            for target in targets[:]:
                target.update()
                if target.size <= 0:
                    targets.remove(target)
                    misses += 1
                elif click_occurred and target.collide(*mouse_pos):
                    if target.fruit_type == 0: counts["orange"] += 1
                    elif target.fruit_type == 1: counts["grape"] += 1
                    elif target.fruit_type == 2: counts["melon"] += 1
                    elif target.fruit_type == 3: counts["banana"] += 1
                    elif target.fruit_type == 4: counts["mango"] += 1
                    elif target.fruit_type == 5: counts["apple"] += 1
                    score += target.points
                    hits += 1
                    targets.remove(target)
                    click_occurred = False

            WIN.fill(BG_COLOR)
            for target in targets: target.draw(WIN)
            draw_top_bar(WIN, remaining_time, score, counts, misses)
            pygame.display.update()

        if not restart:
            break

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())
